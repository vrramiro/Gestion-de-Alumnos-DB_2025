Curso: K3673
Número de grupo: 30
Integrantes:
Vera, Ramiro - 2092270
Marchese, Milagros - 2090697
Cosenza, Lucía - 2025350
Tuma, Nicolas - 1687920
Email del responsable: ravera@frba.utn.edu.ar